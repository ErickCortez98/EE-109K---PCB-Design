Fusion file is in .f3z format as .f3d was not an option

After unzipping look for "Final Board and Enclosure"
